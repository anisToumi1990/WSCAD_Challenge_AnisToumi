﻿namespace WSCAD_Challenge.Services
{
    public interface IFileDialogService
    {
        string OpenFile(string filter);
    }

}
