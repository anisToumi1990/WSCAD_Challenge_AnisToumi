﻿using System.Windows;
using WSCAD_Challenge.Models.Shapes;

namespace WSCAD_Challenge.Utilities.DrawingStrategies
{
    public interface IDrawingStrategy
    {
        UIElement GetShapeToDraw(IShape shape, double zoom);

        Rect GetBoundingBox(IShape shape);
    }
}
