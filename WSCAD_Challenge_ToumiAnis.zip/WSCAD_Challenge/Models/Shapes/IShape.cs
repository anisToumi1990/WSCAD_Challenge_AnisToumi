﻿using System.Windows.Media;

namespace WSCAD_Challenge.Models.Shapes
{
    public interface IShape
    {
        public Color Color { get; set; }
    }
}
